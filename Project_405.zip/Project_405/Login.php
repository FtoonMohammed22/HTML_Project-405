<?php
session_start();
include 'test_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $query->bind_param("s", $email);
    $query->execute();
    $result = $query->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
       // echo "Login successful!";
       header("Location: index.html");
    exit();
    } else {
        header("Location: Signup.html");
    exit();
    }

    $conn->close();
}
?>
