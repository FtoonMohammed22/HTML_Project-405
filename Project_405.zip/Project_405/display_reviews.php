<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "toota";
$database = "princess";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve reviews from the contact_form table
$result = $conn->query("SELECT name, comments, referrer FROM client_reviews ORDER BY id DESC LIMIT 5");

echo "<div class='reviews-container'>";
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='review-card'>";
        echo "<p class='review-text'>" . htmlspecialchars($row["comments"]) . "</p>";
        echo "<p class='review-author'>- " . htmlspecialchars($row["name"]) . "</p>";
        echo "</div>";
    }
} else {
    echo "<p>No reviews yet. Be the first to leave a review!</p>";
}
echo "</div>";

// Close the connection
$conn->close();
?>
