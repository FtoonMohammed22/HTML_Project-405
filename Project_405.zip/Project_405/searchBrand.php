<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search Results</title>
    <link rel="stylesheet" href="Style.css">
</head>
<body>
    <h2>Search Results</h2>
    <div class="clothing-container">
        <?php
        // Database connection settings
        $servername = "localhost";
        $username = "root"; 

        $password = "toota"; 
        $dbname = "princess"; 
        // Connect to the database
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check the connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }



        // Check if the search parameter is set
        if (isset($_GET['brand'])) {
            $brand = $_GET['brand'];
            $sql = "SELECT * FROM clothes_table WHERE brand LIKE '%$brand%'";
            $result = $conn->query($sql);

            // Display results
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo '<div class="clothing-item">';

                    echo '<img src="' . $row["image"] . '" alt="' . $row["description"] . '" class="clothing-image">';

                    echo '<p class="clothing-brand">' . $row["brand"] . '</p>';
                    echo '<p class="clothing-description">' . $row["description"] . '</p>';
                    echo '<p class="clothing-price">' . $row["price"] . ' SR</p>';
                    echo '<label for="size-select" class="size-label">Select Size:</label>';
                    echo '<select id="size-select" class="size-select">
                            <option value="newborn">Newborn (0-3 months)</option>
                            <option value="3-6">3-6 months</option>
                            <option value="6-9">6-9 months</option>
                            <option value="9-12">9-12 months</option>
                            <option value="12-18">12-18 months</option>
                            <option value="18-24">18-24 months</option>
                          </select>';
                    echo '</div>';
                }
            } else {
                echo "<p>No results found for the brand '$brand'.</p>";
            }
        } else {
            echo "<p>Brand parameter is not set.</p>";
        }

        // Close the database connection
        $conn->close();
        ?>
    </div>
</body>

</html>

