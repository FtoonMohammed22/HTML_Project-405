<?php
include 'test_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];

    // Hash new password
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Update password in the database
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
    $stmt->bind_param("ss", $hashed_password, $email);

    if ($stmt->execute()) {
       // echo "Password reset successful!";
       header("Location: loginPage.html"); // Replace with the correct login page URL
            exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $conn->close();
}
?>
