<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Style.css"> 
    <title>Submission Successful</title>
</head>
<body>
  
    <img src="assets/header.png" alt="Logo">

  
    <ul class="menu">
        <li><a href="/index.html">Home</a></li>
        <li><a href="/Clothes_page.html">Clothes</a></li>
        <li><a href="/Accessories_page.html">Accessories</a></li>
        <li><a href="/Review_page.html">Your Voice Matters</a></li>
    </ul>

    <div class="content">
        <h1>Submission Successful!</h1>
        <p>Thank you for your feedback! Your review has been submitted successfully.</p>
        <a href="/index.html" class="button">Return to Home Page</a> 
    </div>
</body>
</html>
