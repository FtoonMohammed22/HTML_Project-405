<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="Style.css">
<style>


.review-section{
  background-color:#f2e9eb;
}

    </style>
</head>
<body>
  <img src="assets/header.png" alt="Logo">
  <ul class="menu">
      <li><a href="/index.html">Home</a></li>
      <li><a href="/Clothes_page.php">Clothes</a></li>
      <li><a href="/Accessories_page.html">Accessories</a></li>
      <li><a href="/Review_page.html">Your Voice Matters</a></li>
  </ul>


   <!-- Search -->
   <div class="search-container">
  <form action="searchBrand.php" method="GET">
    <input type="text" name="brand" placeholder="Search here..." required>
    <button type="submit">Search</button>
  </form>
</div>

    <!--size table-->
    <div>
    <h3>Baby Sizing Guide</h3>
    <table id="babytable">
    <tr class="head">
        <th>Size</th>
        <th>Height (cm)</th>
        <th>Weight (kg)</th>
    </tr>
    <tr class="content">
        <td>Newborn</td>
        <td>50-60</td>
        <td>3-5</td>
    </tr>
    <tr  class="content">
        <td>3-6 months</td>
        <td>60-66</td>
        <td>5-7</td>
    </tr>
    <tr  class="content">
        <td>6-9 months</td>
        <td>66-74</td>
        <td>7-8</td>
    </tr>
    <tr  class="content">
        <td>9-12 months</td>
        <td>74-80</td>
        <td>8-10</td>
    </tr>
    <tr  class="content">
        <td>12-18 months</td>
        <td>80-86</td>
        <td>10-12</td>
    </tr>
    <tr  class="content">
        <td>18-24 months</td>
        <td>86-92</td>
        <td>12-14</td>
    </tr>
</table>
<h3>Baby Clothes Collection</h3>
  <!-- Container for the clothing items -->
  <div class="clothing-container">
      <!-- Example of a Clothing Item -->
      <div class="clothing-item">
          <img src="assets/babshirt.png" alt="Baby Outfit" class="clothing-image">
          <p class="clothing-brand">MONNALISA</p>
          <p class="clothing-description">Pink cotton jersey sweatshirt with floral print</p>
          <p class="clothing-price">183.30 SR</p>
          <label for="size-select-1" class="size-label">Select Size:</label>
          <select id="size-select-1" class="size-select">
              <option value="newborn">Newborn (0-3 months)</option>
              <option value="3-6">3-6 months</option>
              <option value="6-9">6-9 months</option>
              <option value="9-12">9-12 months</option>
              <option value="12-18">12-18 months</option>
              <option value="18-24">18-24 months</option>
          </select>
      </div>

      <div class="clothing-item">
          <img src="assets/pants.png" alt="Baby Joggers" class="clothing-image">
          <p class="clothing-brand">MONNALISA</p>
          <p class="clothing-description">Baby girls' cotton jersey joggers, light pink</p>
          <p class="clothing-price">164.40 SR</p>
          <label for="size-select-2" class="size-label">Select Size:</label>
          <select id="size-select-2" class="size-select">
              <option value="newborn">Newborn (0-3 months)</option>
              <option value="3-6">3-6 months</option>
              <option value="6-9">6-9 months</option>
              <option value="9-12">9-12 months</option>
              <option value="12-18">12-18 months</option>
              <option value="18-24">18-24 months</option>
          </select>
      </div>

      <div class="clothing-item">
          <img src="assets/shoes.png" alt="Baby Shoes" class="clothing-image">
          <p class="clothing-brand">MOSCHINO BABY</p>
          <p class="clothing-description">Cute baby shoes with teddy bear design</p>
          <p class="clothing-price">653 SR</p>
          <label for="size-select-3" class="size-label">Select Size:</label>
          <select id="size-select-3" class="size-select">
              <option value="newborn">Newborn (0-3 months)</option>
              <option value="3-6">3-6 months</option>
              <option value="6-9">6-9 months</option>
              <option value="9-12">9-12 months</option>
              <option value="12-18">12-18 months</option>
              <option value="18-24">18-24 months</option>
          </select>
      </div>

      <div class="clothing-item">
          <img src="assets/full.png" alt="Baby Tracksuit" class="clothing-image">
          <p class="clothing-brand">MOSCHINO BABY</p>
          <p class="clothing-description">Blue teddy bear print cotton pique tracksuit</p>
          <p class="clothing-price">479.40 SR</p>
          <label for="size-select-4" class="size-label">Select Size:</label>
          <select id="size-select-4" class="size-select">
              <option value="newborn">Newborn (0-3 months)</option>
              <option value="3-6">3-6 months</option>
              <option value="6-9">6-9 months</option>
              <option value="9-12">9-12 months</option>
              <option value="12-18">12-18 months</option>
              <option value="18-24">18-24 months</option>
          </select>
      </div>

      <div class="clothing-item">
          <img src="assets/full2.png" alt="Baby Shorts Set" class="clothing-image">
          <p class="clothing-brand">GUESS</p>
          <p class="clothing-description">Blue and white cotton jersey shorts set for newborns</p>
          <p class="clothing-price">150 SR</p>
          <label for="size-select-5" class="size-label">Select Size:</label>
          <select id="size-select-5" class="size-select">
              <option value="newborn">Newborn (0-3 months)</option>
              <option value="3-6">3-6 months</option>
              <option value="6-9">6-9 months</option>
              <option value="9-12">9-12 months</option>
              <option value="12-18">12-18 months</option>
              <option value="18-24">18-24 months</option>
          </select>
      </div>

      <div class="clothing-item">
          <img src="assets/pants2.png" alt="Baby Leggings" class="clothing-image">
          <p class="clothing-brand">MONNALISA</p>
          <p class="clothing-description">Girls' leggings with Disney print, purple cotton</p>
          <p class="clothing-price">136.50 SR</p>
          <label for="size-select-6" class="size-label">Select Size:</label>
          <select id="size-select-6" class="size-select">
              <option value="newborn">Newborn (0-3 months)</option>
              <option value="3-6">3-6 months</option>
              <option value="6-9">6-9 months</option>
              <option value="9-12">9-12 months</option>
              <option value="12-18">12-18 months</option>
              <option value="18-24">18-24 months</option>
          </select>
      </div>
    </div>
  </div>
</div>
             <!-- Reviews Section -->
    <div class="review-section">
    <h3>Customer Reviews</h3>
    <div id="reviews-container">
    <?php include 'display_reviews.php'; ?>
</body>
</html>
