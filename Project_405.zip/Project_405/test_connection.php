<?php
$servername = "localhost";
<<<<<<< HEAD
$username = "root";
$password = "toota";
$database = "princess";

$conn = new mysqli($servername, $username, $password, $database);
=======
$username = "root";      
$password = "123";
$dbname="little";
            


$conn = new mysqli($servername, $username, $password,$dbname);
>>>>>>> 1b2e45e691feea2ed637274c7e57d13e705b695d

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Connected successfully!";
?>

