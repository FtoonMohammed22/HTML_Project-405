<?php
session_start();
include 'test_connection.php'; // Ensure this file connects to the correct database

if (!isset($_SESSION['user_id'])) {
// Redirect to login if not logged in
header("Location: loginPage.html");
exit();
}

$user_id = $_SESSION['user_id'];

// Prepare a statement to delete the user from the database
$query = $conn->prepare("DELETE FROM users WHERE id = ?");
$query->bind_param("i", $user_id);

if ($query->execute()) {
// Account deleted successfully
echo "Account deleted successfully.";

// Destroy the session to log the user out
session_unset();
session_destroy();

// Redirect to the signup or login page (or any other page as desired)
header("Location: signup.html");
exit();
} else {
echo "Error deleting account: " . $conn->error;
}

$query->close();
$conn->close();
?>