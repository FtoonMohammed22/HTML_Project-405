<?php
// Database configuration
$servername = "localhost"; 
$username = "root";         
$password = "toota";           
$database = "princess";  

// Connect to MySQL
$conn = new mysqli($servername, $username, $password);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create the database
$sql = "CREATE DATABASE IF NOT EXISTS $database";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully (or already exists).<br>";
} else {
    echo "Error creating database: " . $conn->error;
}

// Select the database
$conn->select_db($database);

// Create the table
$sql = "CREATE TABLE IF NOT EXISTS client_reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    comments TEXT,
    referrer ENUM('social-media', 'family-friends', 'ads') NOT NULL
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'client_reviews' created successfully (or already exists).";
} else {
    echo "Error creating table: " . $conn->error;
}

// Close the connection
$conn->close();
?>
