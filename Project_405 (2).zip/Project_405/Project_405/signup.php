<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'test_connection.php';  // Connect to the database
    
    $first_name = $_POST['FirstName'];
    $last_name = $_POST['LastName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone = $_POST['Phone'];
    $country = $_POST['country'];
    $city = $_POST['city'];
    $age_group = $_POST['age'];
    $location = $_POST['Location'];

    // Check if email already exists
    $query = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $query->bind_param("s", $email);
    $query->execute();
    $result = $query->get_result();
    
    if ($result->num_rows > 0) {
        echo "User already exists. Please <a href='loginPage.html'>log in</a>."; // Update 'loginPage.html' with the actual login page URL
    } else {
        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert user data
        $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, password, phone, country, city, age_group, location) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssssss", $first_name, $last_name, $email, $hashed_password, $phone, $country, $city, $age_group, $location);
        
        if ($stmt->execute()) {
            //echo "Registration successful!";
            header("Location: loginPage.html"); // Replace with the correct login page URL
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    }
    
    $conn->close();
}
?>
