<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Search Results</title>
    <link rel="stylesheet" href="Style.css">
</head>
<body>
  <img src="assets/header.png" alt="Logo">
  <ul class="menu">
      <li><a href="/index.html">Home</a></li>
      <li><a href="/Clothes_page.php">Clothes</a></li>
      <li><a href="/Accessories_page.html">Toys</a></li>
      <li><a href="/Review_page.html">Your Voice Matters</a></li>
  </ul>
  <h1>Clothes</h1>
  <!--size table-->
  <div>
    <h3>Baby Sizing Guide</h3>
    <table id="babytable">
    <tr class="head">
        <th>Size</th>
        <th>Height (cm)</th>
        <th>Weight (kg)</th>
    </tr>
    <tr class="content">
        <td>Newborn</td>
        <td>50-60</td>
        <td>3-5</td>
    </tr>
    <tr  class="content">
        <td>3-6 months</td>
        <td>60-66</td>
        <td>5-7</td>
    </tr>
    <tr  class="content">
        <td>6-9 months</td>
        <td>66-74</td>
        <td>7-8</td>
    </tr>
    <tr  class="content">
        <td>9-12 months</td>
        <td>74-80</td>
        <td>8-10</td>
    </tr>
    <tr  class="content">
        <td>12-18 months</td>
        <td>80-86</td>
        <td>10-12</td>
    </tr>
    <tr  class="content">
        <td>18-24 months</td>
        <td>86-92</td>
        <td>12-14</td>
    </tr>
</table>
<h3>Search Results</h3>
  
    <div class="clothing-container">
        <?php
        // Database connection settings
        $servername = "localhost";
        $username = "root"; 

        $password = "new"; 
        $dbname = "little_princess"; 
        // Connect to the database
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check the connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }



        // Check if the search parameter is set
        if (isset($_GET['brand'])) {
            $brand = $_GET['brand'];
            $sql = "SELECT * FROM clothes_table WHERE brand LIKE '%$brand%'";
            $result = $conn->query($sql);

            // Display results
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo '<div class="clothing-item">';

                    echo '<img src="' . $row["image"] . '" alt="' . $row["description"] . '" class="clothing-image">';

                    echo '<p class="clothing-brand">' . $row["brand"] . '</p>';
                    echo '<p class="clothing-description">' . $row["description"] . '</p>';
                    echo '<p class="clothing-price">' . $row["price"] . ' SR</p>';
                    echo '<label for="size-select" class="size-label">Select Size:</label>';
                    echo '<select id="size-select" class="size-select">
                            <option value="newborn">Newborn (0-3 months)</option>
                            <option value="3-6">3-6 months</option>
                            <option value="6-9">6-9 months</option>
                            <option value="9-12">9-12 months</option>
                            <option value="12-18">12-18 months</option>
                            <option value="18-24">18-24 months</option>
                          </select>';
                    echo '</div>';
                }
            } else {
                echo "<p>No results found for the brand '$brand'.</p>";
            }
        } else {
            echo "<p>Brand parameter is not set.</p>";
        }

        // Close the database connection
        $conn->close();
        ?>
    </div>
</body>

</html>

