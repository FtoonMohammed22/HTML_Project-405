<?php

// Database configuration
$servername = "localhost";
$username = "root";
$password = "toota";
$database = "princess";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize an empty array for errors
$errors = [];

// Retrieve form data and validate each field
$name = $_POST['name'];
$email = $_POST['email'];
$comments = $_POST['comments'];
$referrer = $_POST['referrer'];

// Name validation
if (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
    $errors[] = "Name can only contain letters and spaces.";
}

// Email validation
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Invalid email format.";
}

// Comments length validation
if (strlen($comments) > 500) {
    $errors[] = "Comments must be 500 characters or less.";
}

// Referrer validation
if (!in_array($referrer, ["social-media", "family-friends", "ads"])) {
    $errors[] = "No option selected.";
}

// If there are validation errors, display them and stop the script
if (!empty($errors)) {
    foreach ($errors as $error) {
        echo "<p style='color:red;'>$error</p>";
    }
    exit; // Stop further processing if there are errors
}

// Prepare SQL query to insert data if valid
$stmt = $conn->prepare("INSERT INTO client_reviews (name, email, comments, referrer) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $name, $email, $comments, $referrer);

// Execute the query and check for success
if ($stmt->execute()) {
    header("Location: success.php"); 
    exit();
} else {
    echo "Error: " . $stmt->error;
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
