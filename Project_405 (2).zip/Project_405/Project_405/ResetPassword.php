<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <link rel="stylesheet" href="Style.css">
</head>
<body>
    <img src="assets/header.png" alt="Logo">
    <ul class="menu">
        <li><a href="/index.html">Home</a></li>
        <li><a href="/Clothes_page.html">Clothes</a></li>
        <li><a href="/Accessories_page.html">Accessories</a></li>
        <li><a href="/Review_page.html">Your Voice Matters</a></li>
        <li><a href="/loginPage.html">Login</a></li>
    </ul>

    <div style="text-align: center; margin-top: 50px; font-family: Arial, sans-serif;">
        <?php
        include 'test_connection.php';

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $email = $_POST['email'];
            $new_password = $_POST['new_password'];

            // Check if the email exists in the database
            $check_query = $conn->prepare("SELECT * FROM users WHERE email = ?");
            $check_query->bind_param("s", $email);
            $check_query->execute();
            $result = $check_query->get_result();

            if ($result->num_rows > 0) {
                // Email exists, proceed with password update
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $update_query = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
                $update_query->bind_param("ss", $hashed_password, $email);

                if ($update_query->execute()) {
                    echo "<h2>Password updated successfully!</h2>";
                } else {
                    echo "<h2 style='color: red;'>Error updating password: " . $conn->error . "</h2>";
                }

                $update_query->close();
            } else {
                // Email does not exist, redirect to signup page with a message
                echo "<script>
                    alert('You don\'t have an account. Please sign up.');
                    window.location.href = 'signup.html';
                    </script>";
            }

            $check_query->close();
            $conn->close();
        }
        ?>
    </div>
</body>
</html>
