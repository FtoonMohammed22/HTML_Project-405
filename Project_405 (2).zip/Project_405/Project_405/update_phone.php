<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Update Confirmation</title>
    <link rel="stylesheet" href="Style.css">
</head>
<body>
    <img src="assets/header.png" alt="Logo">
    <ul class="menu">
        <li><a href="/index.html">Home</a></li>
        <li><a href="/Clothes_page.php">Clothes</a></li>
        <li><a href="/Accessories_page.html">Toys</a></li>
        <li><a href="/Review_page.html">Your Voice Matters</a></li>
    </ul>

    <div style="text-align: center;">
        <?php
        session_start();
        include 'test_connection.php';

        // Check if the user is logged in
        if (!isset($_SESSION['user_id'])) {
            // Redirect to login if not logged in
            header("Location: loginPage.html");
            exit();
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Get the new phone number from the form
            $new_phone = $_POST['phone'];
            $user_id = $_SESSION['user_id']; // Get the user ID from the session

            // Update the phone number in the database
            $query = $conn->prepare("UPDATE users SET phone = ? WHERE id = ?");
            $query->bind_param("si", $new_phone, $user_id);

            // Execute the query and provide feedback
            if ($query->execute()) {
                echo "<h2>Phone number updated successfully!</h2>";
            } else {
                echo "<h2 style='color: red;'>Error updating phone number: " . $conn->error . "</h2>";
            }

            // Close the query and connection
            $query->close();
            $conn->close();
        }
        ?></div>
       
</body>
</html>
