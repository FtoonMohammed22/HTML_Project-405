<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Update Confirmation</title>
    <link rel="stylesheet" href="Style.css">
</head>
<body>
    <img src="assets/header.png" alt="Logo">
    <ul class="menu">
        <li><a href="/index.html">Home</a></li>
        <li><a href="/Clothes_page.php">Clothes</a></li>
        <li><a href="/Accessories_page.html">Toys</a></li>
        <li><a href="/Review_page.html">Your Voice Matters</a></li>
    </ul><?php
include 'test_connection.php';  // Ensure this connects to your database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format.";
        exit();
    }

    // Insert email into subscribers table
    $query = $conn->prepare("INSERT INTO subscribers (email) VALUES (?)");
    $query->bind_param("s", $email);

    if ($query->execute()) {
        header("Location: thank_you.html");
    exit();
    } else {
        // Check if email already exists
        if ($conn->errno == 1062) {
            echo "You have already subscribed!";
        } else {
            echo "Error: " . $conn->error;
        }
    }

    $query->close();
    $conn->close();
}
?></body></html>